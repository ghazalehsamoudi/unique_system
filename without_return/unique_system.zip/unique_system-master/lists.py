#list's to save the scrapped data's.
list_digikala = []
list_olfa = []
list_amazon = []
