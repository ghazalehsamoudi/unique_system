from urls import urls
#Define menu url's to easier accessibility.
menu_urls = {
    "digikala": urls["digikala"],
    "olfa": urls["olfa"],
    "amazon": urls["amazon"]
}
